//
//  ViewController.swift
//  Capstone
//
//  Created by Varun Raghav Ramesh on 11/23/17.
//  Copyright © 2017 VRSquare. All rights reserved.
//  Sources:
//  Alamofire: https://github.com/Alamofire/Alamofire/blob/master/Documentation/Usage.md
//  Add button with code: https://stackoverflow.com/questions/38416182/swift3-add-button-with-code
//  Getting around ATS: https://stackoverflow.com/questions/30731785/how-do-i-load-an-http-url-with-app-transport-security-enabled-in-ios-9


import UIKit
import Alamofire

class ViewController: UIViewController {
    
    @IBOutlet var startCoordinatesTextField: UITextField!
    @IBOutlet var endCoordinatesTextField: UITextField!
    @IBOutlet var startButton: UIButton!
    
    let gridWidth = 4
    let gridLength = 9
    
    var buttonArray = [String]()
    var tagToGrid = [Int: (Int, Int)]()
    var buttonChecked = [Int: Bool]()
    var numClicks = 0
    var startLocation = (-1, -1)
    var endLocation = (-1, -1)
    var startLocationCount = -1
    var endLocationCount = -1
    var buttonStateStart = true
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        setupButtons()
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    func setupButtons() {
        
        let startX = 65
        let startY = 50
        let startWidth = 60
        let startHeight = 60
        
        var count = 0
        for i in 0..<self.gridWidth {
            
            for j in 0..<self.gridLength {
                
                let button = UIButton(type: UIButtonType.system)
                button.frame = CGRect(x:startX + (i*startWidth), y:startY + (j*startHeight), width:startWidth, height:startHeight)
                button.tag = count
                button.backgroundColor = UIColor.white
                button.layer.cornerRadius = 0
                button.layer.borderWidth = 3
                button.layer.borderColor = UIColor.black.cgColor
                
                self.tagToGrid[count] = (self.gridLength - 1 - j, i)
                self.buttonChecked[count] = false
                
                button.addTarget(self, action: #selector(ViewController.gridButtonsPressed(_:)), for: .touchUpInside)
                self.view.addSubview(button)
                
                count += 1
            }
        }
    }
    
    @objc func gridButtonsPressed(_ sender:UIButton) {
        print(sender.tag)
        let gridValue = self.tagToGrid[sender.tag]
        
        if self.numClicks == 0 {
            sender.backgroundColor = UIColor.blue
            self.numClicks += 1
            self.startLocation = gridValue!
            self.startLocationCount = sender.tag
        }
        
        else if self.numClicks == 1 {
            if(self.buttonChecked[sender.tag] == false) {
                self.buttonChecked[sender.tag] = true
                sender.backgroundColor = UIColor.red
                self.numClicks += 1
                self.endLocation = gridValue!
                self.endLocationCount = sender.tag
            }
            
            else {
                self.buttonChecked[sender.tag] = false
                sender.backgroundColor = UIColor.white
                self.numClicks -= 1
                self.endLocation = (-1, -1)
                self.startLocation = (-1, -1)
                self.startLocationCount = -1
            }
            
        }
        
        else {
            if(self.buttonChecked[sender.tag] == false) {
                let alert = UIAlertController(title: "Error", message: "Too many points selected", preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                    self.present(alert, animated: true, completion: nil)
                
            }
            
            else {
                self.buttonChecked[sender.tag] = false
                sender.backgroundColor = UIColor.white
                self.numClicks -= 1
                
                if sender.tag == self.startLocationCount {
                    self.startLocation = self.endLocation
                    self.endLocation = (-1, -1)
                    
                    self.startLocationCount = self.endLocationCount
                    self.endLocationCount = -1
                    
                }
                
                else if sender.tag == self.endLocationCount {
                    self.endLocation = (-1, -1)
                    self.endLocationCount = -1
                }
                
            }
        }
    }
    
    func performStartButtonPressed(_ sender: UIButton) {
        if self.numClicks != 2 {
            
            let alert = UIAlertController(title: "Error", message: "Select a start and end point", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                NSLog("The \"OK\" alert occured.")
            }))
            self.present(alert, animated: true, completion: nil)
            
        }
            
        else {

            let parameters: Parameters = [
                "startRow": startLocation.0,
                "startCol": startLocation.1,
                "endRow": endLocation.0,
                "endCol": endLocation.1
            ]
            
            print(startLocation)
            print(endLocation)
            
            // All three of these calls are equivalent
            Alamofire.request("http://128.237.233.114:8000", method: .post, parameters: parameters, encoding: JSONEncoding.default)
                .responseJSON { response in
                    print(response)
            }
        }
    }

    @IBAction func startButtonPressed(_ sender: UIButton) {
        
        if(self.buttonStateStart) {
            performStartButtonPressed(sender)
            self.buttonStateStart = false
            self.startButton.setTitle("Stop", for: UIControlState.normal)
        }
        
        else {
            self.buttonStateStart = true
            self.startButton.setTitle("Start", for: UIControlState.normal)
        }
        
        
    }
    

    
}

